# ATAPay

A stablecoin payments platform built on Arc Mainnet. Send, receive, and request USDC, create payment links, issue invoices, and track payments — all using real on-chain transactions.

## Tech Stack

- **Frontend**: React 18, TypeScript, Vite
- **Styling**: Tailwind CSS
- **Wallet**: wagmi v2, viem, ConnectKit
- **Chain**: Arc Mainnet (Chain ID 5042)
- **Token**: USDC (`0x3600000000000000000000000000000000000000`)
- **QR Codes**: qrcode.react

## Local Development

```bash
bun install
bun run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Deploy to Vercel

1. Push this repository to GitHub.
2. Import the project on [vercel.com](https://vercel.com).
3. Vercel will auto-detect Vite. The `vercel.json` already configures:
   - Build command: `bun run build`
   - Output directory: `dist`
   - SPA rewrites so all routes resolve to `index.html`
4. Deploy — no environment variables are required for the base app.

### Optional: WalletConnect

If you want WalletConnect support, add `VITE_WALLETCONNECT_PROJECT_ID` to your Vercel environment variables and update `src/config.ts` to include the WalletConnect connector.

## Network Configuration

| Setting | Value |
|---------|-------|
| Network | Arc Mainnet |
| Chain ID | 5042 |
| RPC | https://rpc.mainnet.arc.io |
| USDC Contract | 0x3600000000000000000000000000000000000000 |
| Explorer | https://explorer.arc.io |
| Gas Token | USDC |

## Security Notes

- Never share your seed phrase or private key.
- All transactions are on Arc Mainnet and are irreversible once confirmed.
- Merchant profile data is stored in your browser's localStorage only.
- Always verify recipient addresses before sending.
