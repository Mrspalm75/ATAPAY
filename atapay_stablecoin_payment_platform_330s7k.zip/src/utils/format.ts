import { buildTxExplorerUrl, buildAddressExplorerUrl } from '@/onchain-facts'
import { ARC_CHAIN_ID } from '@/config'

export function formatAddress(addr: string): string {
  if (!addr) return ''
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`
}

export function formatUSDC(amount: string | number): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount
  if (isNaN(num)) return '$0.00'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 6,
  }).format(num)
}

export function formatDate(ts: number | string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(ts))
}

export function explorerTxUrl(hash: string): string {
  return buildTxExplorerUrl(ARC_CHAIN_ID, hash)
}

export function explorerAddressUrl(address: string): string {
  return buildAddressExplorerUrl(ARC_CHAIN_ID, address)
}

export function generatePaymentId(): string {
  return 'pay_' + Math.random().toString(36).slice(2, 11) + Date.now().toString(36)
}

export function generateInvoiceNumber(): string {
  const now = new Date()
  const y = now.getFullYear()
  const m = String(now.getMonth() + 1).padStart(2, '0')
  const seq = String(Math.floor(Math.random() * 9000) + 1000)
  return `INV-${y}${m}-${seq}`
}

export function isValidAddress(addr: string): boolean {
  return /^0x[0-9a-fA-F]{40}$/.test(addr)
}
