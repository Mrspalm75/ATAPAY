// Local storage utilities for payment links, invoices, and app state.
// The blockchain is the source of truth for settlement; this is only for UI state.

export interface PaymentLink {
  id: string
  amount: string // '' for open amount
  description: string
  reference: string
  recipientAddress: string
  expiryDate: string // ISO string, '' for no expiry
  status: 'active' | 'expired' | 'cancelled'
  createdAt: number
  paidTxHash?: string
  paidAt?: number
}

export interface Invoice {
  id: string
  invoiceNumber: string
  recipientAddress: string
  customerEmail: string
  customerRef: string
  items: Array<{ description: string; amount: string }>
  totalUsdc: string
  createdAt: number
  dueDate: string
  status: 'draft' | 'unpaid' | 'pending' | 'paid' | 'expired' | 'cancelled'
  paymentLinkId?: string
  paidTxHash?: string
  paidAt?: number
  merchantName: string
  notes: string
}

export interface MerchantProfile {
  businessName: string
  payoutAddress: string
  email: string
  website: string
  logoInitials: string
}

const STORAGE_KEYS = {
  PAYMENT_LINKS: 'atapay_payment_links',
  INVOICES: 'atapay_invoices',
  MERCHANT: 'atapay_merchant',
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    if (!raw) return fallback
    return JSON.parse(raw) as T
  } catch {
    return fallback
  }
}

function save<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value))
}

// Payment Links
export function getPaymentLinks(): PaymentLink[] {
  return load<PaymentLink[]>(STORAGE_KEYS.PAYMENT_LINKS, [])
}

export function savePaymentLink(link: PaymentLink): void {
  const links = getPaymentLinks()
  const idx = links.findIndex((l) => l.id === link.id)
  if (idx >= 0) links[idx] = link
  else links.unshift(link)
  save(STORAGE_KEYS.PAYMENT_LINKS, links)
}

export function deletePaymentLink(id: string): void {
  const links = getPaymentLinks().filter((l) => l.id !== id)
  save(STORAGE_KEYS.PAYMENT_LINKS, links)
}

// Invoices
export function getInvoices(): Invoice[] {
  return load<Invoice[]>(STORAGE_KEYS.INVOICES, [])
}

export function saveInvoice(invoice: Invoice): void {
  const invoices = getInvoices()
  const idx = invoices.findIndex((i) => i.id === invoice.id)
  if (idx >= 0) invoices[idx] = invoice
  else invoices.unshift(invoice)
  save(STORAGE_KEYS.INVOICES, invoices)
}

export function deleteInvoice(id: string): void {
  const invoices = getInvoices().filter((i) => i.id !== id)
  save(STORAGE_KEYS.INVOICES, invoices)
}

// Merchant Profile
export function getMerchantProfile(): MerchantProfile {
  return load<MerchantProfile>(STORAGE_KEYS.MERCHANT, {
    businessName: '',
    payoutAddress: '',
    email: '',
    website: '',
    logoInitials: '',
  })
}

export function saveMerchantProfile(profile: MerchantProfile): void {
  save(STORAGE_KEYS.MERCHANT, profile)
}
