// Arc onchain constants — Arc Mainnet (chain ID 5042)
// Source: https://docs.arc.io

export const USDC_DECIMALS = 6

export interface TokenFact {
  symbol: string
  address: string
  decimals: number
}

export interface NativeCurrencyFact {
  symbol: string
  decimals: number
  isUsdc: boolean
}

export interface OnchainChain {
  chainId: number
  name: string
  isTestnet: boolean
  family?: string
  explorerBase: string
  rpcUrls: string[]
  nativeCurrency: NativeCurrencyFact
  usdc?: TokenFact
  cctpDomain?: number
  scpBlockchain?: string
}

export interface ProtocolContractFact {
  name: string
  address: string
  protocol: 'CCTP' | 'Gateway'
  networkKind?: 'testnet' | 'mainnet'
}

export const ONCHAIN_CHAINS: readonly OnchainChain[] = [
  {
    chainId: 5042,
    name: 'Arc',
    isTestnet: false,
    family: 'arc',
    explorerBase: 'https://explorer.arc.io',
    rpcUrls: ['https://rpc.mainnet.arc.io'],
    nativeCurrency: { symbol: 'USDC', decimals: 18, isUsdc: true },
    usdc: {
      symbol: 'USDC',
      address: '0x3600000000000000000000000000000000000000',
      decimals: 6,
    },
    cctpDomain: 26,
  },
  {
    chainId: 5042002,
    name: 'Arc Testnet',
    isTestnet: true,
    family: 'arc',
    explorerBase: 'https://explorer.testnet.arc.io',
    rpcUrls: ['https://rpc.testnet.arc.io'],
    nativeCurrency: { symbol: 'USDC', decimals: 18, isUsdc: true },
    usdc: {
      symbol: 'USDC',
      address: '0x3600000000000000000000000000000000000000',
      decimals: 6,
    },
    cctpDomain: 26,
    scpBlockchain: 'ARC-TESTNET',
  },
  {
    chainId: 1,
    name: 'Ethereum',
    isTestnet: false,
    explorerBase: 'https://etherscan.io',
    rpcUrls: ['https://ethereum.reth.rs/rpc'],
    nativeCurrency: { symbol: 'ETH', decimals: 18, isUsdc: false },
    usdc: {
      symbol: 'USDC',
      address: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
      decimals: 6,
    },
  },
]

export const TESTNET_ONCHAIN_CHAINS: readonly OnchainChain[] = ONCHAIN_CHAINS.filter(
  (c) => c.isTestnet,
)

export const EVM_PROTOCOL_CONTRACTS: readonly ProtocolContractFact[] = []

const BY_CHAIN_ID = new Map(ONCHAIN_CHAINS.map((chain) => [chain.chainId, chain]))

export function getChain(chainId: number): OnchainChain | undefined {
  return BY_CHAIN_ID.get(chainId)
}

export function requireChain(chainId: number): OnchainChain {
  const chain = getChain(chainId)
  if (!chain) throw new Error(`Unknown chain ID ${chainId}`)
  return chain
}

export function getUsdc(chainId: number): TokenFact | undefined {
  return getChain(chainId)?.usdc
}

export function buildAddressExplorerUrl(chainId: number, address: string): string {
  return requireChain(chainId).explorerBase + '/address/' + address
}

export function buildTxExplorerUrl(chainId: number, txHash: string): string {
  return requireChain(chainId).explorerBase + '/tx/' + txHash
}
