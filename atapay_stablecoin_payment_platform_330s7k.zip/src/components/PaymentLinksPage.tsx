import { useState, useEffect } from 'react'
import { useAccount } from 'wagmi'
import { QRCodeSVG } from 'qrcode.react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link2, Plus, Copy, Check, Trash2, ExternalLink, X, ToggleLeft, Wallet } from 'lucide-react'
import { toast } from 'sonner'
import { getPaymentLinks, savePaymentLink, deletePaymentLink, type PaymentLink } from '@/utils/storage'
import { generatePaymentId, formatDate } from '@/utils/format'

const APP_BASE = window.location.origin

function PaymentLinkCard({ link, onCopy, onDelete, onDeactivate, now }: {
  link: PaymentLink
  onCopy: () => void
  onDelete: () => void
  onDeactivate: () => void
  now: number
}) {
  const [copied, setCopied] = useState(false)
  const url = `${APP_BASE}/pay/${link.id}`
  const expiryTs = link.expiryDate ? new Date(link.expiryDate).getTime() : null
  const isExpired = expiryTs !== null && expiryTs < now
  const effectiveStatus = isExpired ? 'expired' : link.status

  function copyLink() {
    void navigator.clipboard.writeText(url)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    toast.success('Payment link copied')
    onCopy()
  }

  const statusColors: Record<string, string> = {
    active: 'text-[#8dd89f] bg-[rgba(141,216,159,0.1)] border-[rgba(141,216,159,0.25)]',
    expired: 'text-[var(--subtle)] bg-[var(--surface-muted)] border-[var(--border)]',
    cancelled: 'text-[#e86d7a] bg-[rgba(232,109,122,0.1)] border-[rgba(232,109,122,0.25)]',
  }

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm text-[var(--ink)] truncate">{link.description || 'Payment Link'}</p>
          {link.reference && <p className="text-xs text-[var(--subtle)] truncate">Ref: {link.reference}</p>}
        </div>
        <span className={`shrink-0 text-xs font-semibold px-2 py-0.5 rounded-full border ${statusColors[effectiveStatus] ?? statusColors.active}`}>
          {effectiveStatus}
        </span>
      </div>

      <div className="flex items-center gap-2">
        <span className="display text-lg font-bold text-[var(--ink)] tabular-nums">
          {link.amount ? `$${link.amount} USDC` : 'Open amount'}
        </span>
      </div>

      <div className="mono text-xs text-[var(--subtle)] bg-[var(--surface-muted)] rounded-lg px-3 py-2 truncate border border-[var(--border)]">
        {url}
      </div>

      {link.expiryDate && (
        <p className="text-xs text-[var(--subtle)]">Expires: {formatDate(link.expiryDate)}</p>
      )}

      <div className="flex gap-2 pt-1">
        <button
          onClick={copyLink}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--surface-muted)] border border-[var(--border)] text-xs font-medium text-[var(--muted)] hover:text-[var(--ink)] transition-colors"
        >
          {copied ? <Check size={13} className="text-[#8dd89f]" /> : <Copy size={13} />}
          Copy
        </button>
        {effectiveStatus === 'active' && (
          <button
            onClick={onDeactivate}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[var(--surface-muted)] border border-[var(--border)] text-xs font-medium text-[var(--muted)] hover:text-[var(--ink)] transition-colors"
          >
            <ToggleLeft size={13} />
            Deactivate
          </button>
        )}
        <button
          onClick={onDelete}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[#e86d7a] hover:bg-[rgba(232,109,122,0.1)] border border-transparent hover:border-[rgba(232,109,122,0.2)] transition-colors ml-auto"
        >
          <Trash2 size={13} />
          Delete
        </button>
      </div>
    </div>
  )
}

export default function PaymentLinksPage() {
  const { address, isConnected } = useAccount()
  const [links, setLinks] = useState<PaymentLink[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [selectedLink, setSelectedLink] = useState<PaymentLink | null>(null)
  const [renderNow] = useState(() => Date.now())

  // Form state
  const [formAmount, setFormAmount] = useState('')
  const [formDescription, setFormDescription] = useState('')
  const [formReference, setFormReference] = useState('')
  const [formExpiry, setFormExpiry] = useState('')

  useEffect(() => {
    setLinks(getPaymentLinks())
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function refresh() { setLinks(getPaymentLinks()) }

  function handleCreate() {
    if (!address) return
    const link: PaymentLink = {
      id: generatePaymentId(),
      amount: formAmount,
      description: formDescription,
      reference: formReference,
      recipientAddress: address,
      expiryDate: formExpiry,
      status: 'active',
      createdAt: Date.now(),
    }
    savePaymentLink(link)
    refresh()
    setShowCreate(false)
    setFormAmount(''); setFormDescription(''); setFormReference(''); setFormExpiry('')
    toast.success('Payment link created')
  }

  function handleDeactivate(id: string) {
    const link = links.find((l) => l.id === id)
    if (!link) return
    savePaymentLink({ ...link, status: 'cancelled' })
    refresh()
    toast.success('Link deactivated')
  }

  function handleDelete(id: string) {
    deletePaymentLink(id)
    refresh()
    toast.success('Link deleted')
  }

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to create payment links</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="display text-xl font-bold text-[var(--ink)]">Payment Links</h2>
          <p className="text-xs text-[var(--subtle)] mt-0.5">Shareable checkout links for USDC payments</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-bold text-sm hover:bg-[var(--accent-hover)] transition-colors"
        >
          <Plus size={16} />
          New Link
        </button>
      </div>

      {links.length === 0 ? (
        <div className="rounded-xl border border-dashed border-[var(--border)] bg-[var(--surface)] p-12 flex flex-col items-center gap-3 text-center">
          <Link2 size={32} className="text-[var(--subtle)]" />
          <p className="text-[var(--muted)] font-medium">No payment links yet</p>
          <p className="text-xs text-[var(--subtle)]">Create a shareable link so customers can pay you USDC</p>
          <button onClick={() => setShowCreate(true)} className="mt-2 text-sm text-[var(--accent)] hover:underline flex items-center gap-1">
            <Plus size={14} /> Create your first link
          </button>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {links.map((link) => (
            <PaymentLinkCard
              key={link.id}
              link={link}
              now={renderNow}
              onCopy={() => {}}
              onDelete={() => handleDelete(link.id)}
              onDeactivate={() => handleDeactivate(link.id)}
            />
          ))}
        </div>
      )}

      {/* Create modal */}
      <AnimatePresence>
        {showCreate && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 z-40" onClick={() => setShowCreate(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97 }}
              className="fixed inset-x-4 top-1/2 -translate-y-1/2 z-50 max-w-md mx-auto"
            >
              <div className="rounded-2xl border border-[var(--border-strong)] bg-[#0f1e34] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="display text-lg font-bold text-[var(--ink)]">New Payment Link</h3>
                  <button onClick={() => setShowCreate(false)} className="text-[var(--subtle)] hover:text-[var(--ink)]"><X size={18} /></button>
                </div>

                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Amount (leave blank for open)</label>
                    <div className="relative">
                      <input type="number" value={formAmount} onChange={(e) => setFormAmount(e.target.value)} placeholder="0.00" min="0" step="0.01"
                        className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 pr-16 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]" />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)] font-semibold">USDC</span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Description</label>
                    <input type="text" value={formDescription} onChange={(e) => setFormDescription(e.target.value)} placeholder="e.g. Consulting fee"
                      className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]" />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Reference (optional)</label>
                    <input type="text" value={formReference} onChange={(e) => setFormReference(e.target.value)} placeholder="e.g. INV-001"
                      className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]" />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Expiry Date (optional)</label>
                    <input type="datetime-local" value={formExpiry} onChange={(e) => setFormExpiry(e.target.value)}
                      className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] focus:outline-none focus:border-[var(--border-strong)]" />
                  </div>
                </div>

                {/* QR preview */}
                {address && (
                  <div className="flex justify-center py-2">
                    <div className="p-3 bg-white rounded-xl">
                      <QRCodeSVG value={`${APP_BASE}/pay/${generatePaymentId()}`} size={120} level="M" />
                    </div>
                  </div>
                )}
                <p className="text-xs text-[var(--subtle)] text-center">A unique shareable link will be generated</p>

                <div className="flex gap-3 pt-1">
                  <button onClick={() => setShowCreate(false)} className="flex-1 py-2.5 rounded-xl border border-[var(--border)] text-[var(--muted)] text-sm font-semibold hover:bg-[var(--surface)] transition-colors">Cancel</button>
                  <button onClick={handleCreate} className="flex-1 py-2.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] text-sm font-bold hover:bg-[var(--accent-hover)] transition-colors">Create Link</button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* QR detail modal */}
      <AnimatePresence>
        {selectedLink && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 z-40" onClick={() => setSelectedLink(null)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-x-4 top-1/2 -translate-y-1/2 z-50 max-w-sm mx-auto"
            >
              <div className="rounded-2xl border border-[var(--border-strong)] bg-[#0f1e34] p-6 space-y-4 text-center">
                <div className="flex justify-between items-center">
                  <h3 className="display text-lg font-bold text-[var(--ink)]">Payment QR</h3>
                  <button onClick={() => setSelectedLink(null)} className="text-[var(--subtle)] hover:text-[var(--ink)]"><X size={18} /></button>
                </div>
                <div className="flex justify-center">
                  <div className="p-4 bg-white rounded-2xl">
                    <QRCodeSVG value={`${APP_BASE}/pay/${selectedLink.id}`} size={180} level="H" />
                  </div>
                </div>
                <p className="mono text-xs text-[var(--subtle)] break-all">{`${APP_BASE}/pay/${selectedLink.id}`}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => { void navigator.clipboard.writeText(`${APP_BASE}/pay/${selectedLink.id}`); toast.success('Copied') }}
                    className="flex-1 py-2 rounded-lg border border-[var(--border)] text-[var(--muted)] text-sm font-medium hover:bg-[var(--surface)] flex items-center justify-center gap-1.5"
                  >
                    <Copy size={14} /> Copy Link
                  </button>
                  <a
                    href={`${APP_BASE}/pay/${selectedLink.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2 rounded-lg bg-[var(--accent)] text-[#0d1b2f] text-sm font-bold hover:bg-[var(--accent-hover)] flex items-center justify-center gap-1.5"
                  >
                    Open <ExternalLink size={14} />
                  </a>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
