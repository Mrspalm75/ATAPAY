import { useState, useEffect } from 'react'
import { useAccount, useReadContract, usePublicClient } from 'wagmi'
import { erc20Abi } from 'viem'
import { motion } from 'framer-motion'
import {
  ArrowUpRight,
  ArrowDownLeft,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Wallet,
  Zap,
} from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { getUsdc } from '@/onchain-facts'
import { Amount } from '@/onchain-money'
import { ARC_CHAIN_ID } from '@/config'
import { formatAddress, explorerTxUrl } from '@/utils/format'
import type { Page } from './Layout'

const USDC_ADDRESS = getUsdc(ARC_CHAIN_ID)!.address as `0x${string}`
const USDC_DECIMALS = getUsdc(ARC_CHAIN_ID)!.decimals

function StatCard({
  label,
  value,
  sub,
  icon,
  accent,
}: {
  label: string
  value: string
  sub?: string
  icon: React.ReactNode
  accent?: string
}) {
  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)]">{label}</span>
        <span className={`p-2 rounded-lg bg-[var(--surface-strong)] ${accent ?? 'text-[var(--accent)]'}`}>{icon}</span>
      </div>
      <div>
        <p className="display text-2xl font-bold text-[var(--ink)] tabular-nums">{value}</p>
        {sub && <p className="text-xs text-[var(--subtle)] mt-0.5">{sub}</p>}
      </div>
    </div>
  )
}

interface TxRecord {
  hash: string
  direction: 'in' | 'out'
  amount: string
  from: string
  to: string
  timestamp: number
  status: 'confirmed'
}

export default function Dashboard({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const { address, isConnected } = useAccount()
  const [recentTxs, setRecentTxs] = useState<TxRecord[]>([])
  const [loadingTxs, setLoadingTxs] = useState(false)
  const publicClient = usePublicClient({ chainId: ARC_CHAIN_ID })

  const { data: rawBalance, isLoading: balanceLoading } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: ARC_CHAIN_ID,
    query: { enabled: !!address },
  })

  const formattedBalance =
    rawBalance !== undefined
      ? Amount.fromRaw(rawBalance, USDC_DECIMALS).toFixed(2)
      : null

  // Fetch recent Transfer events involving this address
  useEffect(() => {
    if (!address || !publicClient) return
    let cancelled = false
    async function fetchTxs() {
      if (!address || !publicClient) return
      setLoadingTxs(true)
      try {
        const transferEvent = {
          type: 'event' as const,
          name: 'Transfer',
          inputs: [
            { type: 'address' as const, name: 'from', indexed: true as const },
            { type: 'address' as const, name: 'to', indexed: true as const },
            { type: 'uint256' as const, name: 'value' },
          ],
        }
        type TLog = { transactionHash: `0x${string}` | null; args?: { value?: bigint; from?: string; to?: string } }
        const toMe: TLog[] = await publicClient.getLogs({
          address: USDC_ADDRESS, event: transferEvent,
          args: { to: address }, fromBlock: 'earliest', toBlock: 'latest',
        }).then((r) => r as TLog[]).catch(() => [])

        const fromMe: TLog[] = await publicClient.getLogs({
          address: USDC_ADDRESS, event: transferEvent,
          args: { from: address }, fromBlock: 'earliest', toBlock: 'latest',
        }).then((r) => r as TLog[]).catch(() => [])

        if (cancelled) return

        const all: TxRecord[] = [
          ...toMe.map((log) => ({
            hash: log.transactionHash ?? '',
            direction: 'in' as const,
            amount: Amount.fromRaw(
              (log as { args?: { value?: bigint } }).args?.value ?? 0n,
              USDC_DECIMALS,
            ).toFixed(2),
            from: ((log as { args?: { from?: string } }).args?.from ?? ''),
            to: address,
            timestamp: 0,
            status: 'confirmed' as const,
          })),
          ...fromMe.map((log) => ({
            hash: log.transactionHash ?? '',
            direction: 'out' as const,
            amount: Amount.fromRaw(
              (log as { args?: { value?: bigint } }).args?.value ?? 0n,
              USDC_DECIMALS,
            ).toFixed(2),
            from: address,
            to: log.args?.to ?? '',
            timestamp: 0,
            status: 'confirmed' as const,
          })),
        ]

        // Sort by block number descending (latest first); take last 5
        const sorted = all.slice(-5).reverse()
        setRecentTxs(sorted)
      } finally {
        if (!cancelled) setLoadingTxs(false)
      }
    }
    void fetchTxs()
    return () => { cancelled = true }
  }, [address, publicClient])

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] gap-6 px-4">
        <div className="w-16 h-16 rounded-2xl bg-[rgba(172,198,233,0.15)] flex items-center justify-center">
          <Wallet size={32} className="text-[var(--accent)]" />
        </div>
        <div className="text-center">
          <h2 className="display text-2xl font-bold text-[var(--ink)] mb-2">Connect your wallet</h2>
          <p className="text-[var(--muted)] max-w-sm">
            Connect a browser wallet to view your USDC balance and start making payments on Arc Mainnet.
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-[rgba(141,216,159,0.1)] border border-[rgba(141,216,159,0.2)]">
          <Zap size={14} className="text-[#8dd89f]" />
          <span className="text-xs text-[#8dd89f] font-medium">Gas paid in USDC on Arc Mainnet</span>
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-6">
      {/* Hero balance */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl border border-[rgba(172,198,233,0.2)] bg-gradient-to-br from-[rgba(172,198,233,0.1)] to-[rgba(13,27,47,0.4)] p-6"
      >
        <div className="flex items-start justify-between mb-2">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)]">USDC Balance</p>
            <p className="mono text-xs text-[var(--subtle)] mt-0.5">{formatAddress(address ?? '')}</p>
          </div>
          <TokenUSDC variant="branded" size={32} />
        </div>
        {balanceLoading ? (
          <div className="h-12 w-40 bg-[var(--surface-strong)] rounded-lg animate-pulse mt-2" />
        ) : (
          <p className="display text-4xl font-bold text-[var(--ink)] tabular-nums mt-2">
            {formattedBalance !== null ? `$${formattedBalance}` : '$0.00'}
            <span className="text-lg text-[var(--subtle)] ml-2 font-medium">USDC</span>
          </p>
        )}
        <p className="text-xs text-[var(--subtle)] mt-1">Arc Mainnet · Chain ID 5042</p>

        <div className="flex gap-3 mt-5">
          <button
            onClick={() => onNavigate('send')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-semibold text-sm hover:bg-[var(--accent-hover)] transition-colors"
          >
            <ArrowUpRight size={16} />
            Send
          </button>
          <button
            onClick={() => onNavigate('receive')}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[var(--surface-strong)] border border-[var(--border)] text-[var(--ink)] font-semibold text-sm hover:bg-[rgba(255,255,255,0.14)] transition-colors"
          >
            <ArrowDownLeft size={16} />
            Receive
          </button>
        </div>
      </motion.div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          label="Total Received"
          value={recentTxs.filter((t) => t.direction === 'in').length > 0 ? '–' : '$0.00'}
          sub="from blockchain"
          icon={<ArrowDownLeft size={16} />}
          accent="text-[#8dd89f]"
        />
        <StatCard
          label="Total Sent"
          value={recentTxs.filter((t) => t.direction === 'out').length > 0 ? '–' : '$0.00'}
          sub="from blockchain"
          icon={<ArrowUpRight size={16} />}
          accent="text-[#e86d7a]"
        />
        <StatCard
          label="Payments"
          value={String(recentTxs.length)}
          sub="transactions found"
          icon={<CheckCircle2 size={16} />}
        />
        <StatCard
          label="Pending"
          value="0"
          sub="awaiting confirmation"
          icon={<Clock size={16} />}
          accent="text-[var(--subtle)]"
        />
      </div>

      {/* Quick actions */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)] mb-3">Quick Actions</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Create Payment Link', page: 'payments' as Page, icon: <TrendingUp size={18} /> },
            { label: 'Issue Invoice', page: 'invoices' as Page, icon: <FileTextIcon /> },
            { label: 'View Transactions', page: 'transactions' as Page, icon: <Clock size={18} /> },
            { label: 'Merchant Tools', page: 'merchant' as Page, icon: <AlertCircle size={18} /> },
          ].map((action) => (
            <button
              key={action.page}
              onClick={() => onNavigate(action.page)}
              className="flex flex-col items-center gap-2 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-strong)] transition-colors text-center"
            >
              <span className="text-[var(--accent)]">{action.icon}</span>
              <span className="text-xs font-medium text-[var(--muted)]">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent activity */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)]">Recent Activity</p>
          <button onClick={() => onNavigate('transactions')} className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1">
            View all <ExternalLink size={11} />
          </button>
        </div>
        <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
          {loadingTxs ? (
            <div className="p-8 text-center text-[var(--subtle)] text-sm">Loading transactions...</div>
          ) : recentTxs.length === 0 ? (
            <div className="p-8 text-center">
              <Clock size={28} className="text-[var(--subtle)] mx-auto mb-2" />
              <p className="text-[var(--subtle)] text-sm">No transactions yet on Arc Mainnet</p>
              <p className="text-xs text-[var(--subtle)] mt-1">Your USDC transfers will appear here</p>
            </div>
          ) : (
            <ul className="divide-y divide-[var(--border)]">
              {recentTxs.map((tx) => (
                <li key={tx.hash} className="flex items-center gap-3 px-4 py-3 hover:bg-[var(--surface-strong)] transition-colors">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    tx.direction === 'in' ? 'bg-[rgba(141,216,159,0.15)] text-[#8dd89f]' : 'bg-[rgba(232,109,122,0.15)] text-[#e86d7a]'
                  }`}>
                    {tx.direction === 'in' ? <ArrowDownLeft size={15} /> : <ArrowUpRight size={15} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-[var(--ink)]">
                      {tx.direction === 'in' ? `From ${formatAddress(tx.from)}` : `To ${formatAddress(tx.to)}`}
                    </p>
                    <p className="mono text-xs text-[var(--subtle)] truncate">{tx.hash.slice(0, 18)}...</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className={`text-sm font-semibold tabular-nums ${tx.direction === 'in' ? 'text-[#8dd89f]' : 'text-[#e86d7a]'}`}>
                      {tx.direction === 'in' ? '+' : '-'}${tx.amount}
                    </p>
                    <a
                      href={explorerTxUrl(tx.hash)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-[var(--accent)] hover:underline flex items-center gap-0.5 justify-end"
                    >
                      Explorer <ExternalLink size={10} />
                    </a>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  )
}

function FileTextIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <polyline points="10 9 9 9 8 9" />
    </svg>
  )
}
