import { useState, useEffect } from 'react'
import { useAccount } from 'wagmi'
import { Settings, Save, Check, ExternalLink, AlertTriangle, Wallet } from 'lucide-react'
import { getMerchantProfile, saveMerchantProfile, type MerchantProfile } from '@/utils/storage'
import { explorerAddressUrl, isValidAddress } from '@/utils/format'
import { toast } from 'sonner'
import { ARC_CHAIN_ID } from '@/config'

export default function SettingsPage() {
  const { address, isConnected } = useAccount()
  const [saved, setSaved] = useState(false)
  const [profile, setProfile] = useState<MerchantProfile>({
    businessName: '',
    payoutAddress: '',
    email: '',
    website: '',
    logoInitials: '',
  })

  useEffect(() => {
    const p = getMerchantProfile()
    setProfile(p)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function update<K extends keyof MerchantProfile>(key: K, value: MerchantProfile[K]) {
    setProfile((p) => ({ ...p, [key]: value }))
  }

  function handleSave() {
    saveMerchantProfile(profile)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
    toast.success('Settings saved')
  }

  const payoutAddressError = profile.payoutAddress && !isValidAddress(profile.payoutAddress)
    ? 'Invalid address format' : ''

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to manage settings</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-[rgba(172,198,233,0.15)] flex items-center justify-center">
          <Settings size={18} className="text-[var(--accent)]" />
        </div>
        <div>
          <h2 className="display text-xl font-bold text-[var(--ink)]">Settings</h2>
          <p className="text-xs text-[var(--subtle)]">Merchant profile and configuration</p>
        </div>
      </div>

      {/* Connected wallet info */}
      <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 space-y-1">
        <p className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Connected Wallet</p>
        <div className="flex items-center gap-2">
          <p className="mono text-sm text-[var(--ink)] break-all">{address}</p>
          <a href={explorerAddressUrl(address ?? '')} target="_blank" rel="noopener noreferrer" className="text-[var(--accent)] hover:underline shrink-0">
            <ExternalLink size={13} />
          </a>
        </div>
        <p className="text-xs text-[var(--subtle)]">Arc Mainnet · Chain ID {ARC_CHAIN_ID}</p>
      </div>

      {/* Merchant profile */}
      <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
        <p className="text-sm font-bold text-[var(--ink)]">Merchant Profile</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Business Name</label>
            <input
              type="text"
              value={profile.businessName}
              onChange={(e) => update('businessName', e.target.value)}
              placeholder="Your Business Name"
              className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Logo Initials</label>
            <input
              type="text"
              value={profile.logoInitials}
              onChange={(e) => update('logoInitials', e.target.value.slice(0, 2).toUpperCase())}
              placeholder="AB"
              maxLength={2}
              className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Contact Email</label>
            <input
              type="email"
              value={profile.email}
              onChange={(e) => update('email', e.target.value)}
              placeholder="contact@yourbusiness.com"
              className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Website</label>
            <input
              type="url"
              value={profile.website}
              onChange={(e) => update('website', e.target.value)}
              placeholder="https://yourbusiness.com"
              className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Payout Wallet Address</label>
          <input
            type="text"
            value={profile.payoutAddress}
            onChange={(e) => update('payoutAddress', e.target.value.trim())}
            placeholder="0x... (Arc Mainnet address)"
            className="w-full mono text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
          />
          {payoutAddressError && <p className="text-xs text-[#e86d7a]">{payoutAddressError}</p>}
          <p className="text-xs text-[var(--subtle)]">Leave blank to use the connected wallet as your payout address.</p>
        </div>
      </div>

      {/* Security notice */}
      <div className="rounded-xl border border-[rgba(251,191,36,0.2)] bg-[rgba(251,191,36,0.05)] p-4 flex gap-3">
        <AlertTriangle size={18} className="text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-sm font-semibold text-amber-400">Security Reminder</p>
          <ul className="text-xs text-[var(--muted)] space-y-0.5 list-disc list-inside">
            <li>Never share your seed phrase or private key with ATAPay or anyone else.</li>
            <li>Always verify the recipient address before sending USDC.</li>
            <li>Arc Mainnet transactions are irreversible once confirmed.</li>
            <li>ATAPay stores merchant profile data in your browser only — no server-side account.</li>
          </ul>
        </div>
      </div>

      {/* Network info */}
      <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Network Configuration</p>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            { label: 'Network', value: 'Arc Mainnet' },
            { label: 'Chain ID', value: String(ARC_CHAIN_ID) },
            { label: 'RPC', value: 'rpc.mainnet.arc.io' },
            { label: 'Gas Token', value: 'USDC' },
            { label: 'USDC Contract', value: '0x36000...00000' },
            { label: 'Explorer', value: 'explorer.arc.io' },
          ].map((row) => (
            <div key={row.label} className="flex items-center justify-between gap-2">
              <span className="text-[var(--subtle)]">{row.label}</span>
              <span className="mono text-[var(--muted)] text-right">{row.value}</span>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={handleSave}
        disabled={!!payoutAddressError}
        className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-bold text-sm hover:bg-[var(--accent-hover)] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
      >
        {saved ? <><Check size={16} /> Saved!</> : <><Save size={16} /> Save Settings</>}
      </button>
    </div>
  )
}
