import { useState, useEffect } from 'react'
import { useAccount } from 'wagmi'
import { motion, AnimatePresence } from 'framer-motion'
import { FileText, Plus, X, Trash2, ExternalLink, Wallet, CheckCircle2, Clock, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'
import { getInvoices, saveInvoice, deleteInvoice, getMerchantProfile, type Invoice } from '@/utils/storage'
import { generatePaymentId, generateInvoiceNumber, formatDate, explorerTxUrl } from '@/utils/format'

const STATUS_META: Record<string, { label: string; color: string }> = {
  draft: { label: 'Draft', color: 'text-[var(--subtle)] bg-[var(--surface-muted)] border-[var(--border)]' },
  unpaid: { label: 'Unpaid', color: 'text-[#e86d7a] bg-[rgba(232,109,122,0.08)] border-[rgba(232,109,122,0.25)]' },
  pending: { label: 'Pending', color: 'text-amber-400 bg-[rgba(251,191,36,0.08)] border-[rgba(251,191,36,0.25)]' },
  paid: { label: 'Paid', color: 'text-[#8dd89f] bg-[rgba(141,216,159,0.08)] border-[rgba(141,216,159,0.25)]' },
  expired: { label: 'Expired', color: 'text-[var(--subtle)] bg-[var(--surface-muted)] border-[var(--border)]' },
  cancelled: { label: 'Cancelled', color: 'text-[var(--subtle)] bg-[var(--surface-muted)] border-[var(--border)]' },
}

function InvoiceCard({ invoice, onDelete, onMarkPending, now }: {
  invoice: Invoice
  onDelete: () => void
  onMarkPending: () => void
  now: number
}) {
  const meta = STATUS_META[invoice.status] ?? STATUS_META.unpaid
  const dueTs = invoice.dueDate ? new Date(invoice.dueDate).getTime() : null
  const isDueExpired = dueTs !== null && dueTs < now && invoice.status === 'unpaid'

  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-semibold text-sm text-[var(--ink)]">{invoice.invoiceNumber}</p>
          {invoice.customerEmail && <p className="text-xs text-[var(--subtle)]">{invoice.customerEmail}</p>}
        </div>
        <span className={`shrink-0 text-xs font-semibold px-2 py-0.5 rounded-full border ${meta.color}`}>{meta.label}</span>
      </div>

      <div>
        <p className="display text-xl font-bold text-[var(--ink)] tabular-nums">${invoice.totalUsdc} USDC</p>
        <p className="text-xs text-[var(--subtle)] mt-0.5">Due: {invoice.dueDate ? formatDate(invoice.dueDate) : 'No due date'}</p>
        {isDueExpired && <p className="text-xs text-[#e86d7a] mt-0.5">Overdue</p>}
      </div>

      {invoice.items.map((item, i) => (
        <div key={i} className="flex justify-between text-xs text-[var(--subtle)]">
          <span>{item.description}</span>
          <span className="tabular-nums">${item.amount}</span>
        </div>
      ))}

      {invoice.paidTxHash && (
        <div className="flex items-center gap-1.5 text-xs text-[#8dd89f]">
          <CheckCircle2 size={13} />
          Settled on-chain ·
          <a href={explorerTxUrl(invoice.paidTxHash)} target="_blank" rel="noopener noreferrer" className="hover:underline flex items-center gap-0.5">
            {invoice.paidTxHash.slice(0, 12)}... <ExternalLink size={10} />
          </a>
        </div>
      )}

      <div className="flex gap-2 pt-1">
        {invoice.status === 'unpaid' && (
          <button
            onClick={onMarkPending}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[rgba(251,191,36,0.1)] border border-[rgba(251,191,36,0.2)] text-xs font-medium text-amber-400 hover:bg-[rgba(251,191,36,0.15)] transition-colors"
          >
            <Clock size={13} />
            Mark Pending
          </button>
        )}
        <button
          onClick={onDelete}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[#e86d7a] hover:bg-[rgba(232,109,122,0.08)] border border-transparent hover:border-[rgba(232,109,122,0.2)] transition-colors ml-auto"
        >
          <Trash2 size={13} />
          Delete
        </button>
      </div>
    </div>
  )
}

export default function InvoicesPage() {
  const { address, isConnected } = useAccount()
  const [invoices, setInvoices] = useState<Invoice[]>([])
  const [showCreate, setShowCreate] = useState(false)
  const [filter, setFilter] = useState<Invoice['status'] | 'all'>('all')
  // Snapshot of current time at render — avoids calling Date.now() inside child renders
  const [renderNow] = useState(() => Date.now())

  // Form state
  const [formCustomerEmail, setFormCustomerEmail] = useState('')
  const [formCustomerRef, setFormCustomerRef] = useState('')
  const [formDueDate, setFormDueDate] = useState('')
  const [formNotes, setFormNotes] = useState('')
  const [formItems, setFormItems] = useState([{ description: '', amount: '' }])

  useEffect(() => {
    setInvoices(getInvoices())
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  function refresh() { setInvoices(getInvoices()) }

  function addItem() { setFormItems([...formItems, { description: '', amount: '' }]) }
  function removeItem(i: number) { setFormItems(formItems.filter((_, idx) => idx !== i)) }
  function updateItem(i: number, field: 'description' | 'amount', value: string) {
    const updated = [...formItems]
    updated[i] = { ...updated[i], [field]: value }
    setFormItems(updated)
  }

  const formTotal = formItems.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0).toFixed(2)

  function handleCreate() {
    if (!address) return
    const merchant = getMerchantProfile()
    const invoice: Invoice = {
      id: generatePaymentId(),
      invoiceNumber: generateInvoiceNumber(),
      recipientAddress: address,
      customerEmail: formCustomerEmail,
      customerRef: formCustomerRef,
      items: formItems.filter((i) => i.description || i.amount),
      totalUsdc: formTotal,
      createdAt: Date.now(),
      dueDate: formDueDate,
      status: 'unpaid',
      merchantName: merchant.businessName || 'My Business',
      notes: formNotes,
    }
    saveInvoice(invoice)
    refresh()
    setShowCreate(false)
    setFormCustomerEmail(''); setFormCustomerRef(''); setFormDueDate(''); setFormNotes('')
    setFormItems([{ description: '', amount: '' }])
    toast.success(`Invoice ${invoice.invoiceNumber} created`)
  }

  function handleMarkPending(id: string) {
    const inv = invoices.find((i) => i.id === id)
    if (!inv) return
    saveInvoice({ ...inv, status: 'pending' })
    refresh()
    toast.info('Invoice marked as pending — awaiting on-chain settlement verification')
  }

  function handleDelete(id: string) {
    deleteInvoice(id)
    refresh()
    toast.success('Invoice deleted')
  }

  const filtered = filter === 'all' ? invoices : invoices.filter((i) => i.status === filter)

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to issue invoices</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="display text-xl font-bold text-[var(--ink)]">Invoices</h2>
          <p className="text-xs text-[var(--subtle)] mt-0.5">Issue and track USDC invoices</p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-bold text-sm hover:bg-[var(--accent-hover)] transition-colors"
        >
          <Plus size={16} />
          New Invoice
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {(['all', 'draft', 'unpaid', 'pending', 'paid', 'expired', 'cancelled'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors border ${
              filter === s
                ? 'bg-[var(--accent)] text-[#0d1b2f] border-transparent'
                : 'border-[var(--border)] text-[var(--muted)] hover:text-[var(--ink)] hover:bg-[var(--surface-strong)]'
            }`}
          >
            {s === 'all' ? 'All' : STATUS_META[s].label}
            <span className="ml-1 opacity-60">
              {s === 'all' ? invoices.length : invoices.filter((i) => i.status === s).length}
            </span>
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-[var(--border)] bg-[var(--surface)] p-12 flex flex-col items-center gap-3 text-center">
          <FileText size={32} className="text-[var(--subtle)]" />
          <p className="text-[var(--muted)] font-medium">No invoices yet</p>
          <p className="text-xs text-[var(--subtle)]">Create an invoice and share it with your customers</p>
          <button onClick={() => setShowCreate(true)} className="mt-2 text-sm text-[var(--accent)] hover:underline flex items-center gap-1">
            <Plus size={14} /> Create your first invoice
          </button>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {filtered.map((inv) => (
            <InvoiceCard
              key={inv.id}
              invoice={inv}
              now={renderNow}
              onDelete={() => handleDelete(inv.id)}
              onMarkPending={() => handleMarkPending(inv.id)}
            />
          ))}
        </div>
      )}

      {/* Create modal */}
      <AnimatePresence>
        {showCreate && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 z-40" onClick={() => setShowCreate(false)} />
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 30 }}
              className="fixed inset-x-4 bottom-4 top-4 z-50 max-w-lg mx-auto overflow-y-auto"
            >
              <div className="rounded-2xl border border-[var(--border-strong)] bg-[#0f1e34] p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="display text-lg font-bold text-[var(--ink)]">New Invoice</h3>
                  <button onClick={() => setShowCreate(false)} className="text-[var(--subtle)] hover:text-[var(--ink)]"><X size={18} /></button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Customer Email</label>
                    <input type="email" value={formCustomerEmail} onChange={(e) => setFormCustomerEmail(e.target.value)} placeholder="customer@email.com"
                      className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-3 py-2.5 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Customer Ref</label>
                    <input type="text" value={formCustomerRef} onChange={(e) => setFormCustomerRef(e.target.value)} placeholder="e.g. ACME Corp"
                      className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-3 py-2.5 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Due Date</label>
                  <input type="datetime-local" value={formDueDate} onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-3 py-2.5 text-[var(--ink)] focus:outline-none focus:border-[var(--border-strong)]" />
                </div>

                {/* Line items */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Line Items</label>
                    <button onClick={addItem} className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1"><Plus size={12} /> Add item</button>
                  </div>
                  {formItems.map((item, i) => (
                    <div key={i} className="flex gap-2">
                      <input type="text" value={item.description} onChange={(e) => updateItem(i, 'description', e.target.value)} placeholder="Description"
                        className="flex-1 text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-3 py-2 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]" />
                      <div className="relative w-28">
                        <input type="number" value={item.amount} onChange={(e) => updateItem(i, 'amount', e.target.value)} placeholder="0.00" min="0" step="0.01"
                          className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-3 py-2 pr-12 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)] tabular-nums" />
                        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-[var(--subtle)]">USDC</span>
                      </div>
                      {formItems.length > 1 && (
                        <button onClick={() => removeItem(i)} className="text-[var(--subtle)] hover:text-[#e86d7a] p-1.5"><X size={14} /></button>
                      )}
                    </div>
                  ))}
                  <div className="flex justify-end pt-1">
                    <span className="display text-base font-bold text-[var(--ink)] tabular-nums">Total: ${formTotal} USDC</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Notes (optional)</label>
                  <textarea value={formNotes} onChange={(e) => setFormNotes(e.target.value)} rows={2} placeholder="Payment terms, thank you message..."
                    className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-3 py-2.5 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)] resize-none" />
                </div>

                <div className="flex items-start gap-2 text-xs text-[var(--subtle)] bg-[var(--surface-muted)] rounded-lg p-3 border border-[var(--border)]">
                  <AlertCircle size={13} className="shrink-0 mt-0.5" />
                  Invoices are marked Paid only after verified on-chain settlement, not by manually changing status.
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setShowCreate(false)} className="flex-1 py-2.5 rounded-xl border border-[var(--border)] text-[var(--muted)] text-sm font-semibold hover:bg-[var(--surface)] transition-colors">Cancel</button>
                  <button onClick={handleCreate} disabled={parseFloat(formTotal) <= 0} className="flex-1 py-2.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] text-sm font-bold hover:bg-[var(--accent-hover)] disabled:opacity-40 transition-colors">Create Invoice</button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
