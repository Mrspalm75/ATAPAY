import { useState, useEffect, useCallback } from 'react'
import { useAccount, usePublicClient } from 'wagmi'
import { motion } from 'framer-motion'
import { ArrowUpRight, ArrowDownLeft, ExternalLink, RefreshCw, Wallet, Clock } from 'lucide-react'
import { getUsdc } from '@/onchain-facts'
import { Amount } from '@/onchain-money'
import { ARC_CHAIN_ID } from '@/config'
import { formatAddress, explorerTxUrl, explorerAddressUrl } from '@/utils/format'

interface TransferLog {
  transactionHash: `0x${string}` | null
  blockNumber: bigint | null
  args?: { value?: bigint; from?: string; to?: string }
}

const USDC_ADDRESS = getUsdc(ARC_CHAIN_ID)!.address as `0x${string}`
const USDC_DECIMALS = getUsdc(ARC_CHAIN_ID)!.decimals

interface TxRecord {
  hash: string
  direction: 'in' | 'out'
  amount: string
  amountRaw: bigint
  counterparty: string
  blockNumber: bigint | null
  timestamp: number
  status: 'confirmed'
}

export default function TransactionsPage() {
  const { address, isConnected } = useAccount()
  const publicClient = usePublicClient({ chainId: ARC_CHAIN_ID })
  const [txs, setTxs] = useState<TxRecord[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [filter, setFilter] = useState<'all' | 'in' | 'out'>('all')

  const fetchTransactions = useCallback(async () => {
    if (!address || !publicClient) return
    setLoading(true)
    setError('')
    try {
      const transferEvent = {
        type: 'event' as const,
        name: 'Transfer',
        inputs: [
          { type: 'address' as const, name: 'from', indexed: true as const },
          { type: 'address' as const, name: 'to', indexed: true as const },
          { type: 'uint256' as const, name: 'value' },
        ],
      }
      const empty: TransferLog[] = []
      const [toLogs, fromLogs] = await Promise.all([
        publicClient.getLogs({
          address: USDC_ADDRESS,
          event: transferEvent,
          args: { to: address },
          fromBlock: 'earliest',
          toBlock: 'latest',
        }).then((r) => r as TransferLog[]).catch(() => empty),
        publicClient.getLogs({
          address: USDC_ADDRESS,
          event: transferEvent,
          args: { from: address },
          fromBlock: 'earliest',
          toBlock: 'latest',
        }).then((r) => r as TransferLog[]).catch(() => empty),
      ])

      const seen = new Set<string>()
      const all: TxRecord[] = []

      for (const log of toLogs) {
        const key = `${log.transactionHash}-in`
        if (seen.has(key)) continue
        seen.add(key)
        const logArgs = log.args ?? {}
        all.push({
          hash: log.transactionHash ?? '',
          direction: 'in',
          amountRaw: logArgs.value ?? 0n,
          amount: Amount.fromRaw(logArgs.value ?? 0n, USDC_DECIMALS).toFixed(6),
          counterparty: logArgs.from ?? '',
          blockNumber: log.blockNumber,
          timestamp: 0,
          status: 'confirmed',
        })
      }

      for (const log of fromLogs) {
        const key = `${log.transactionHash}-out`
        if (seen.has(key)) continue
        seen.add(key)
        const logArgs = log.args ?? {}
        all.push({
          hash: log.transactionHash ?? '',
          direction: 'out',
          amountRaw: logArgs.value ?? 0n,
          amount: Amount.fromRaw(logArgs.value ?? 0n, USDC_DECIMALS).toFixed(6),
          counterparty: logArgs.to ?? '',
          blockNumber: log.blockNumber,
          timestamp: 0,
          status: 'confirmed',
        })
      }

      // Sort by block number descending
      all.sort((a, b) => {
        if (a.blockNumber === null) return 1
        if (b.blockNumber === null) return -1
        return Number(b.blockNumber - a.blockNumber)
      })

      setTxs(all)
    } catch {
      setError('Failed to load transactions. RPC may be rate limiting — try again.')
    } finally {
      setLoading(false)
    }
  }, [address, publicClient])

  // eslint-disable-next-line react-hooks/exhaustive-deps -- fetchTransactions is a stable useCallback; this is intentional
  useEffect(() => { void fetchTransactions() }, [fetchTransactions])

  const filtered = filter === 'all' ? txs : txs.filter((t) => t.direction === filter)

  const totalIn = txs
    .filter((t) => t.direction === 'in')
    .reduce((s, t) => s + (parseFloat(t.amount) || 0), 0)
  const totalOut = txs
    .filter((t) => t.direction === 'out')
    .reduce((s, t) => s + (parseFloat(t.amount) || 0), 0)

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to view transactions</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-4xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="display text-xl font-bold text-[var(--ink)]">Transaction History</h2>
          <p className="text-xs text-[var(--subtle)] mt-0.5">On-chain USDC transfers on Arc Mainnet</p>
        </div>
        <button
          onClick={() => { void fetchTransactions() }}
          disabled={loading}
          className="flex items-center gap-2 px-3 py-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--muted)] hover:text-[var(--ink)] text-sm font-medium transition-colors disabled:opacity-50"
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-center">
          <p className="text-xs text-[var(--subtle)] mb-1">Total</p>
          <p className="display text-xl font-bold text-[var(--ink)] tabular-nums">{txs.length}</p>
          <p className="text-xs text-[var(--subtle)]">transactions</p>
        </div>
        <div className="rounded-xl border border-[rgba(141,216,159,0.2)] bg-[rgba(141,216,159,0.05)] p-4 text-center">
          <p className="text-xs text-[#8dd89f] mb-1">Received</p>
          <p className="display text-xl font-bold text-[#8dd89f] tabular-nums">${totalIn.toFixed(2)}</p>
          <p className="text-xs text-[var(--subtle)]">USDC in</p>
        </div>
        <div className="rounded-xl border border-[rgba(232,109,122,0.2)] bg-[rgba(232,109,122,0.05)] p-4 text-center">
          <p className="text-xs text-[#e86d7a] mb-1">Sent</p>
          <p className="display text-xl font-bold text-[#e86d7a] tabular-nums">${totalOut.toFixed(2)}</p>
          <p className="text-xs text-[var(--subtle)]">USDC out</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-1.5">
        {(['all', 'in', 'out'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
              filter === f
                ? 'bg-[var(--accent)] text-[#0d1b2f] border-transparent'
                : 'border-[var(--border)] text-[var(--muted)] hover:text-[var(--ink)] hover:bg-[var(--surface-strong)]'
            }`}
          >
            {f === 'all' ? 'All' : f === 'in' ? 'Received' : 'Sent'}
          </button>
        ))}
      </div>

      {/* Transactions list */}
      <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] overflow-hidden">
        {loading ? (
          <div className="p-12 text-center space-y-3">
            <div className="w-8 h-8 border-2 border-[var(--accent)] border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-[var(--subtle)] text-sm">Scanning Arc Mainnet for USDC transfers...</p>
          </div>
        ) : error ? (
          <div className="p-12 text-center space-y-2">
            <p className="text-[#e86d7a] text-sm">{error}</p>
            <button onClick={() => { void fetchTransactions() }} className="text-xs text-[var(--accent)] hover:underline">Try again</button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <Clock size={32} className="text-[var(--subtle)] mx-auto" />
            <p className="text-[var(--muted)] text-sm">No {filter !== 'all' ? (filter === 'in' ? 'incoming' : 'outgoing') : ''} transactions found</p>
            <p className="text-xs text-[var(--subtle)]">USDC transfers on Arc Mainnet will appear here</p>
          </div>
        ) : (
          <ul className="divide-y divide-[var(--border)]">
            {filtered.map((tx, i) => (
              <motion.li
                key={`${tx.hash}-${tx.direction}`}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.02 }}
                className="flex items-center gap-3 px-4 py-4 hover:bg-[var(--surface-strong)] transition-colors"
              >
                <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                  tx.direction === 'in' ? 'bg-[rgba(141,216,159,0.15)] text-[#8dd89f]' : 'bg-[rgba(232,109,122,0.15)] text-[#e86d7a]'
                }`}>
                  {tx.direction === 'in' ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-[var(--ink)]">
                    {tx.direction === 'in' ? 'Received from' : 'Sent to'}{' '}
                    <a href={explorerAddressUrl(tx.counterparty)} target="_blank" rel="noopener noreferrer" className="hover:underline text-[var(--accent)]">
                      {formatAddress(tx.counterparty)}
                    </a>
                  </p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <a
                      href={explorerTxUrl(tx.hash)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mono text-xs text-[var(--subtle)] hover:text-[var(--accent)] flex items-center gap-0.5 transition-colors"
                    >
                      {tx.hash.slice(0, 16)}... <ExternalLink size={10} />
                    </a>
                    {tx.blockNumber !== null && (
                      <span className="text-xs text-[var(--subtle)]">Block #{tx.blockNumber.toString()}</span>
                    )}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <p className={`display text-base font-bold tabular-nums ${tx.direction === 'in' ? 'text-[#8dd89f]' : 'text-[#e86d7a]'}`}>
                    {tx.direction === 'in' ? '+' : '-'}${parseFloat(tx.amount).toFixed(2)}
                  </p>
                  <p className="text-xs text-[var(--subtle)] mt-0.5">USDC</p>
                </div>
              </motion.li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
