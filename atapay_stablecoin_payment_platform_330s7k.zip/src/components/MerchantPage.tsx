import { useState, useEffect } from 'react'
import { useAccount, useReadContract, usePublicClient } from 'wagmi'
import { erc20Abi } from 'viem'
import { Store, TrendingUp, Users, FileText, Link2, Download, ExternalLink, Wallet } from 'lucide-react'
import { getUsdc } from '@/onchain-facts'
import { Amount } from '@/onchain-money'
import { ARC_CHAIN_ID } from '@/config'
import { getPaymentLinks, getInvoices, getMerchantProfile } from '@/utils/storage'
import { explorerAddressUrl } from '@/utils/format'
import type { Page } from './Layout'

type TransferLog = { args?: { value?: bigint } }

const USDC_ADDRESS = getUsdc(ARC_CHAIN_ID)!.address as `0x${string}`
const USDC_DECIMALS = getUsdc(ARC_CHAIN_ID)!.decimals

function StatCard({ label, value, sub, icon, color }: {
  label: string; value: string | number; sub?: string; icon: React.ReactNode; color?: string
}) {
  return (
    <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)]">{label}</span>
        <span className={`p-2 rounded-lg bg-[var(--surface-strong)] ${color ?? 'text-[var(--accent)]'}`}>{icon}</span>
      </div>
      <p className="display text-2xl font-bold text-[var(--ink)] tabular-nums">{value}</p>
      {sub && <p className="text-xs text-[var(--subtle)]">{sub}</p>}
    </div>
  )
}

export default function MerchantPage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const { address, isConnected } = useAccount()
  const publicClient = usePublicClient({ chainId: ARC_CHAIN_ID })
  const [received, setReceived] = useState(0)
  const [loadingStats, setLoadingStats] = useState(false)

  const { data: rawBalance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: ARC_CHAIN_ID,
    query: { enabled: !!address },
  })

  const formattedBalance = rawBalance !== undefined
    ? Amount.fromRaw(rawBalance, USDC_DECIMALS).toFixed(2)
    : null

  const links = getPaymentLinks()
  const invoices = getInvoices()
  const merchant = getMerchantProfile()

  const activeLinks = links.filter((l) => l.status === 'active').length
  const paidInvoices = invoices.filter((i) => i.status === 'paid').length
  const unpaidInvoices = invoices.filter((i) => i.status === 'unpaid').length
  const pendingInvoices = invoices.filter((i) => i.status === 'pending').length

  useEffect(() => {
    if (!address || !publicClient) return
    let cancelled = false
    async function loadStats() {
      if (!address || !publicClient) return
      setLoadingStats(true)
      try {
        const transferEvent = {
          type: 'event' as const,
          name: 'Transfer',
          inputs: [
            { type: 'address' as const, name: 'from', indexed: true as const },
            { type: 'address' as const, name: 'to', indexed: true as const },
            { type: 'uint256' as const, name: 'value' },
          ],
        }
        const emptyLogs: TransferLog[] = []
        const [toLogs] = await Promise.all([
          publicClient.getLogs({
            address: USDC_ADDRESS,
            event: transferEvent,
            args: { to: address },
            fromBlock: 'earliest',
            toBlock: 'latest',
          }).then((r) => r as TransferLog[]).catch(() => emptyLogs),
          publicClient.getLogs({
            address: USDC_ADDRESS,
            event: transferEvent,
            args: { from: address },
            fromBlock: 'earliest',
            toBlock: 'latest',
          }).then((r) => r as TransferLog[]).catch(() => emptyLogs),
        ])
        if (cancelled) return
        const totalIn = toLogs.reduce((s, l) => {
          const v = l.args?.value ?? 0n
          return s + Number(Amount.fromRaw(v, USDC_DECIMALS).toFixed(6))
        }, 0)
        setReceived(totalIn)
      } finally {
        if (!cancelled) setLoadingStats(false)
      }
    }
    void loadStats()
    return () => { cancelled = true }
  }, [address, publicClient])

  function handleExportCSV() {
    const rows = [
      ['Invoice Number', 'Customer', 'Amount USDC', 'Status', 'Due Date', 'Tx Hash'],
      ...invoices.map((i) => [i.invoiceNumber, i.customerEmail || i.customerRef, i.totalUsdc, i.status, i.dueDate, i.paidTxHash || '']),
    ]
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'atapay-invoices.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to access Merchant Tools</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[rgba(172,198,233,0.08)] to-[rgba(13,27,47,0.4)] p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-[rgba(172,198,233,0.15)] flex items-center justify-center">
            <Store size={22} className="text-[var(--accent)]" />
          </div>
          <div>
            <h2 className="display text-lg font-bold text-[var(--ink)]">{merchant.businessName || 'My Business'}</h2>
            <a href={explorerAddressUrl(address ?? '')} target="_blank" rel="noopener noreferrer" className="mono text-xs text-[var(--subtle)] hover:text-[var(--accent)] flex items-center gap-1 transition-colors">
              {address?.slice(0, 10)}...{address?.slice(-6)} <ExternalLink size={10} />
            </a>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-[var(--subtle)]">Balance</p>
          <p className="display text-xl font-bold text-[var(--ink)] tabular-nums">
            {formattedBalance !== null ? `$${formattedBalance}` : '–'} <span className="text-sm text-[var(--subtle)] font-medium">USDC</span>
          </p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          label="Total Received"
          value={loadingStats ? '...' : `$${received.toFixed(2)}`}
          sub="USDC received on-chain"
          icon={<TrendingUp size={16} />}
          color="text-[#8dd89f]"
        />
        <StatCard
          label="Active Links"
          value={activeLinks}
          sub="payment links live"
          icon={<Link2 size={16} />}
        />
        <StatCard
          label="Invoices Paid"
          value={paidInvoices}
          sub={`${unpaidInvoices + pendingInvoices} outstanding`}
          icon={<FileText size={16} />}
          color="text-[#8dd89f]"
        />
        <StatCard
          label="Customers"
          value={new Set(invoices.map((i) => i.customerEmail).filter(Boolean)).size}
          sub="unique emails"
          icon={<Users size={16} />}
        />
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'New Payment Link', page: 'payments' as Page, icon: <Link2 size={18} /> },
          { label: 'New Invoice', page: 'invoices' as Page, icon: <FileText size={18} /> },
          { label: 'Transactions', page: 'transactions' as Page, icon: <TrendingUp size={18} /> },
          { label: 'Settings', page: 'settings' as Page, icon: <Store size={18} /> },
        ].map((action) => (
          <button
            key={action.page}
            onClick={() => onNavigate(action.page)}
            className="flex flex-col items-center gap-2 p-4 rounded-xl border border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-strong)] transition-colors"
          >
            <span className="text-[var(--accent)]">{action.icon}</span>
            <span className="text-xs font-medium text-[var(--muted)] text-center">{action.label}</span>
          </button>
        ))}
      </div>

      {/* Invoice overview */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)]">Invoice Overview</p>
          <button onClick={handleExportCSV} className="flex items-center gap-1.5 text-xs text-[var(--accent)] hover:underline">
            <Download size={12} /> Export CSV
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Unpaid', count: unpaidInvoices, color: 'text-[#e86d7a]' },
            { label: 'Pending', count: pendingInvoices, color: 'text-amber-400' },
            { label: 'Paid', count: paidInvoices, color: 'text-[#8dd89f]' },
            { label: 'Draft', count: invoices.filter((i) => i.status === 'draft').length, color: 'text-[var(--subtle)]' },
          ].map((s) => (
            <button
              key={s.label}
              onClick={() => onNavigate('invoices')}
              className="rounded-xl border border-[var(--border)] bg-[var(--surface)] p-4 text-center hover:bg-[var(--surface-strong)] transition-colors"
            >
              <p className={`display text-2xl font-bold tabular-nums ${s.color}`}>{s.count}</p>
              <p className="text-xs text-[var(--subtle)] mt-1">{s.label}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Recent payment links */}
      {links.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-semibold uppercase tracking-widest text-[var(--subtle)]">Recent Payment Links</p>
            <button onClick={() => onNavigate('payments')} className="text-xs text-[var(--accent)] hover:underline">View all</button>
          </div>
          <div className="rounded-xl border border-[var(--border)] bg-[var(--surface)] divide-y divide-[var(--border)]">
            {links.slice(0, 5).map((link) => (
              <div key={link.id} className="flex items-center gap-3 px-4 py-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[var(--ink)] truncate">{link.description || 'Payment Link'}</p>
                  <p className="mono text-xs text-[var(--subtle)] truncate">/pay/{link.id.slice(0, 16)}...</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-semibold text-[var(--ink)] tabular-nums">{link.amount ? `$${link.amount}` : 'Open'}</p>
                  <span className={`text-xs font-medium ${link.status === 'active' ? 'text-[#8dd89f]' : 'text-[var(--subtle)]'}`}>{link.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
