import { useState } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useSwitchChain, useReadContract } from 'wagmi'
import { erc20Abi } from 'viem'
import { motion, AnimatePresence } from 'framer-motion'
import { ArrowUpRight, CheckCircle2, AlertCircle, ExternalLink, Loader2, Wallet } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { getUsdc } from '@/onchain-facts'
import { Amount, parseAmount } from '@/onchain-money'
import { ARC_CHAIN_ID } from '@/config'
import { formatAddress, explorerTxUrl, isValidAddress } from '@/utils/format'
import { toast } from 'sonner'

const USDC_ADDRESS = getUsdc(ARC_CHAIN_ID)!.address as `0x${string}`
const USDC_DECIMALS = getUsdc(ARC_CHAIN_ID)!.decimals

type Step = 'form' | 'preview' | 'sending' | 'success' | 'error'

export default function SendPage() {
  const { address, isConnected, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const [step, setStep] = useState<Step>('form')
  const [recipient, setRecipient] = useState('')
  const [amount, setAmount] = useState('')
  const [reference, setReference] = useState('')
  const [note, setNote] = useState('')
  const [txError, setTxError] = useState('')

  const isWrongChain = !!chainId && chainId !== ARC_CHAIN_ID

  const { data: rawBalance } = useReadContract({
    address: USDC_ADDRESS,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: ARC_CHAIN_ID,
    query: { enabled: !!address },
  })

  const balance = rawBalance !== undefined ? Amount.fromRaw(rawBalance, USDC_DECIMALS) : null

  const { writeContract, data: txHash, isPending, reset: resetWrite } = useWriteContract()
  const { isLoading: isConfirming, isSuccess, isError: isTxError, error: txReceiptError } = useWaitForTransactionReceipt({ hash: txHash })

  // Parse amount safely
  let parsedAmount: Amount | null = null
  let parseError = ''
  if (amount) {
    try {
      parsedAmount = parseAmount(ARC_CHAIN_ID, amount)
    } catch {
      parseError = 'Invalid amount'
    }
  }

  const recipientError = recipient && !isValidAddress(recipient) ? 'Invalid address format' : ''
  const balanceError =
    balance && parsedAmount && parsedAmount.gt(balance) ? 'Insufficient USDC balance' : ''
  const canPreview = !parseError && !recipientError && !balanceError && !!recipient && !!amount && parseFloat(amount) > 0

  function handlePreview() {
    if (!canPreview) return
    setStep('preview')
  }

  function handleSend() {
    if (!parsedAmount || !isValidAddress(recipient)) return
    if (isWrongChain) {
      switchChain({ chainId: ARC_CHAIN_ID })
      return
    }
    setTxError('')
    try {
      writeContract({
        address: USDC_ADDRESS,
        abi: erc20Abi,
        functionName: 'transfer',
        args: [recipient as `0x${string}`, parsedAmount.raw],
        chainId: ARC_CHAIN_ID,
      })
      setStep('sending')
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e)
      setTxError(msg)
      setStep('error')
    }
  }

  // Watch for confirmation
  if (isSuccess && step === 'sending') {
    setStep('success')
    toast.success('Payment confirmed on Arc Mainnet')
  }
  if (isTxError && step === 'sending') {
    const msg = txReceiptError?.message ?? 'Transaction failed'
    if (!msg.toLowerCase().includes('user rejected')) {
      setTxError(msg)
    }
    setStep('error')
  }

  function handleReset() {
    setStep('form')
    setRecipient('')
    setAmount('')
    setReference('')
    setNote('')
    setTxError('')
    resetWrite()
  }

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to send USDC</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-lg mx-auto">
      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div key="form" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-5">
              <div className="flex items-center gap-3 mb-1">
                <div className="w-9 h-9 rounded-xl bg-[rgba(172,198,233,0.15)] flex items-center justify-center">
                  <ArrowUpRight size={18} className="text-[var(--accent)]" />
                </div>
                <div>
                  <h2 className="display text-lg font-bold text-[var(--ink)]">Send USDC</h2>
                  <p className="text-xs text-[var(--subtle)]">Arc Mainnet</p>
                </div>
              </div>

              {isWrongChain && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-[rgba(232,109,122,0.1)] border border-[rgba(232,109,122,0.2)] text-sm text-[#e86d7a]">
                  <AlertCircle size={15} />
                  <span>Wrong network. </span>
                  <button onClick={() => switchChain({ chainId: ARC_CHAIN_ID })} className="underline font-medium">
                    Switch to Arc Mainnet
                  </button>
                </div>
              )}

              {/* Recipient */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Recipient Address</label>
                <input
                  type="text"
                  value={recipient}
                  onChange={(e) => setRecipient(e.target.value.trim())}
                  placeholder="0x..."
                  className="w-full mono text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
                />
                {recipientError && <p className="text-xs text-[#e86d7a]">{recipientError}</p>}
              </div>

              {/* Amount */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Amount</label>
                  {balance && (
                    <button
                      onClick={() => setAmount(balance.toFixed(6))}
                      className="text-xs text-[var(--accent)] hover:underline"
                    >
                      Max: ${balance.toFixed(2)}
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    min="0"
                    step="0.000001"
                    className="w-full display text-2xl bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-4 pr-20 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)] tabular-nums"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
                    <TokenUSDC variant="branded" size={20} />
                    <span className="text-sm font-semibold text-[var(--muted)]">USDC</span>
                  </div>
                </div>
                {parseError && <p className="text-xs text-[#e86d7a]">{parseError}</p>}
                {balanceError && <p className="text-xs text-[#e86d7a]">{balanceError}</p>}
              </div>

              {/* Reference */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Payment Reference (optional)</label>
                <input
                  type="text"
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  placeholder="e.g. Invoice #INV-001"
                  className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
                />
              </div>

              {/* Note */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Personal Note (optional)</label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Thanks for your service"
                  className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
                />
              </div>

              <button
                onClick={handlePreview}
                disabled={!canPreview || isWrongChain}
                className="w-full py-3.5 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-bold text-sm hover:bg-[var(--accent-hover)] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                Review Transfer
              </button>
            </div>
          </motion.div>
        )}

        {step === 'preview' && parsedAmount && (
          <motion.div key="preview" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-5">
              <h2 className="display text-lg font-bold text-[var(--ink)]">Confirm Transfer</h2>
              <div className="rounded-xl bg-[var(--surface-muted)] border border-[var(--border)] divide-y divide-[var(--border)]">
                {[
                  { label: 'Recipient', value: <span className="mono text-sm">{formatAddress(recipient)}</span> },
                  { label: 'Amount', value: <span className="display text-xl font-bold tabular-nums">${parsedAmount.toFixed(2)} USDC</span> },
                  { label: 'Network', value: 'Arc Mainnet (Chain ID 5042)' },
                  { label: 'Gas', value: 'Paid in USDC (Arc native)' },
                  ...(reference ? [{ label: 'Reference', value: reference }] : []),
                  ...(note ? [{ label: 'Note', value: note }] : []),
                ].map((row) => (
                  <div key={row.label} className="flex items-center justify-between px-4 py-3">
                    <span className="text-xs text-[var(--subtle)] font-medium">{row.label}</span>
                    <span className="text-sm text-[var(--ink)]">{row.value}</span>
                  </div>
                ))}
              </div>

              <p className="text-xs text-[var(--subtle)] bg-[rgba(172,198,233,0.05)] border border-[rgba(172,198,233,0.1)] rounded-lg p-3">
                Your wallet will ask you to confirm. This is a real USDC transaction on Arc Mainnet and is irreversible once submitted.
              </p>

              <div className="flex gap-3">
                <button onClick={() => setStep('form')} className="flex-1 py-3 rounded-xl border border-[var(--border)] text-[var(--muted)] font-semibold text-sm hover:bg-[var(--surface-strong)] transition-colors">
                  Back
                </button>
                <button
                  onClick={handleSend}
                  disabled={isPending}
                  className="flex-1 py-3 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-bold text-sm hover:bg-[var(--accent-hover)] disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                >
                  {isPending ? <><Loader2 size={16} className="animate-spin" /> Confirm in wallet...</> : 'Confirm & Send'}
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'sending' && (
          <motion.div key="sending" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-8 flex flex-col items-center gap-5">
              <div className="w-16 h-16 rounded-full border-2 border-[var(--accent)] border-t-transparent animate-spin" />
              <div className="text-center">
                <h2 className="display text-lg font-bold text-[var(--ink)] mb-1">
                  {isConfirming ? 'Confirming on Arc...' : 'Waiting for wallet...'}
                </h2>
                <p className="text-[var(--subtle)] text-sm">
                  {isConfirming
                    ? 'Transaction submitted. Waiting for block confirmation.'
                    : 'Please confirm the transaction in your wallet.'}
                </p>
              </div>
              {txHash && (
                <a href={explorerTxUrl(txHash)} target="_blank" rel="noopener noreferrer" className="text-xs text-[var(--accent)] hover:underline flex items-center gap-1">
                  View on Explorer <ExternalLink size={11} />
                </a>
              )}
            </div>
          </motion.div>
        )}

        {step === 'success' && txHash && (
          <motion.div key="success" initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
            <div className="rounded-2xl border border-[rgba(141,216,159,0.3)] bg-[rgba(141,216,159,0.06)] p-8 flex flex-col items-center gap-5 text-center">
              <CheckCircle2 size={52} className="text-[#8dd89f]" />
              <div>
                <h2 className="display text-xl font-bold text-[var(--ink)] mb-1">Payment Sent!</h2>
                <p className="text-[var(--muted)] text-sm">Transaction confirmed on Arc Mainnet</p>
              </div>
              <div className="w-full rounded-xl bg-[var(--surface-muted)] border border-[var(--border)] divide-y divide-[var(--border)]">
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-[var(--subtle)]">To</span>
                  <span className="mono text-sm text-[var(--ink)]">{formatAddress(recipient)}</span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-[var(--subtle)]">Amount</span>
                  <span className="display text-base font-bold text-[#8dd89f] tabular-nums">${parsedAmount?.toFixed(2)} USDC</span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs text-[var(--subtle)]">Tx Hash</span>
                  <a href={explorerTxUrl(txHash)} target="_blank" rel="noopener noreferrer" className="mono text-xs text-[var(--accent)] hover:underline flex items-center gap-1">
                    {txHash.slice(0, 14)}... <ExternalLink size={10} />
                  </a>
                </div>
              </div>
              <button onClick={handleReset} className="w-full py-3 rounded-xl bg-[var(--accent)] text-[#0d1b2f] font-bold text-sm hover:bg-[var(--accent-hover)] transition-colors">
                Send Another
              </button>
            </div>
          </motion.div>
        )}

        {step === 'error' && (
          <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="rounded-2xl border border-[rgba(232,109,122,0.3)] bg-[rgba(232,109,122,0.06)] p-8 flex flex-col items-center gap-5 text-center">
              <AlertCircle size={48} className="text-[#e86d7a]" />
              <div>
                <h2 className="display text-xl font-bold text-[var(--ink)] mb-1">Transaction Failed</h2>
                <p className="text-[var(--muted)] text-sm max-w-sm">
                  {txError.includes('user rejected') || txError.includes('User rejected')
                    ? 'You cancelled the transaction.'
                    : txError || 'Something went wrong. Please try again.'}
                </p>
              </div>
              <button onClick={handleReset} className="w-full py-3 rounded-xl bg-[var(--surface-strong)] border border-[var(--border)] text-[var(--ink)] font-semibold text-sm hover:bg-[rgba(255,255,255,0.14)] transition-colors">
                Try Again
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
