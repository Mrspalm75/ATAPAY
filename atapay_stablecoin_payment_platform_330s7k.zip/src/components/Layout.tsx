import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard,
  ArrowUpRight,
  ArrowDownLeft,
  Link2,
  FileText,
  Clock,
  Store,
  Settings,
  Menu,
  X,
  Zap,
} from 'lucide-react'
import { ConnectKitButton } from 'connectkit'
import { useAccount } from 'wagmi'
import { ARC_CHAIN_ID } from '@/config'
import { useSwitchChain } from 'wagmi'

export type Page =
  | 'dashboard'
  | 'send'
  | 'receive'
  | 'payments'
  | 'invoices'
  | 'transactions'
  | 'merchant'
  | 'settings'

interface LayoutProps {
  currentPage: Page
  onNavigate: (page: Page) => void
  children: React.ReactNode
}

const NAV_ITEMS: { id: Page; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
  { id: 'send', label: 'Send', icon: <ArrowUpRight size={18} /> },
  { id: 'receive', label: 'Receive', icon: <ArrowDownLeft size={18} /> },
  { id: 'payments', label: 'Payments', icon: <Link2 size={18} /> },
  { id: 'invoices', label: 'Invoices', icon: <FileText size={18} /> },
  { id: 'transactions', label: 'Transactions', icon: <Clock size={18} /> },
  { id: 'merchant', label: 'Merchant Tools', icon: <Store size={18} /> },
  { id: 'settings', label: 'Settings', icon: <Settings size={18} /> },
]

function NetworkBadge() {
  const { chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const isArc = chainId === ARC_CHAIN_ID

  if (!chainId) return null

  return (
    <button
      onClick={() => !isArc && switchChain({ chainId: ARC_CHAIN_ID })}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-colors ${
        isArc
          ? 'border-[rgba(141,216,159,0.35)] bg-[rgba(141,216,159,0.12)] text-[#8dd89f]'
          : 'border-[rgba(232,109,122,0.35)] bg-[rgba(232,109,122,0.12)] text-[#e86d7a] cursor-pointer hover:bg-[rgba(232,109,122,0.2)]'
      }`}
    >
      <span
        className={`w-1.5 h-1.5 rounded-full ${isArc ? 'bg-[#8dd89f]' : 'bg-[#e86d7a]'}`}
        style={{ boxShadow: isArc ? '0 0 6px #8dd89f' : '0 0 6px #e86d7a' }}
      />
      {isArc ? 'Arc Mainnet' : 'Wrong Network'}
    </button>
  )
}

export default function Layout({ currentPage, onNavigate, children }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="flex min-h-dvh" style={{ background: 'var(--bg-gradient, var(--bg))' }}>
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 border-r border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] shrink-0">
        <div className="p-6 pb-4 border-b border-[rgba(255,255,255,0.08)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--accent)] flex items-center justify-center">
              <Zap size={16} className="text-[#0d1b2f]" />
            </div>
            <span className="display text-xl font-bold text-[var(--ink)]">ATAPay</span>
          </div>
          <p className="text-xs text-[var(--subtle)] mt-1.5 ml-10">Arc Mainnet</p>
        </div>
        <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                currentPage === item.id
                  ? 'bg-[rgba(172,198,233,0.15)] text-[var(--accent)] border border-[rgba(172,198,233,0.2)]'
                  : 'text-[var(--muted)] hover:bg-[rgba(255,255,255,0.05)] hover:text-[var(--ink)]'
              }`}
            >
              <span className={currentPage === item.id ? 'text-[var(--accent)]' : ''}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-[rgba(255,255,255,0.08)]">
          <p className="text-[10px] text-[var(--subtle)] text-center">
            Real USDC on Arc Mainnet
          </p>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', stiffness: 400, damping: 40 }}
              className="fixed left-0 top-0 bottom-0 w-64 z-50 lg:hidden flex flex-col bg-[#0f1e34] border-r border-[rgba(255,255,255,0.08)]"
            >
              <div className="p-5 pb-4 border-b border-[rgba(255,255,255,0.08)] flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[var(--accent)] flex items-center justify-center">
                    <Zap size={16} className="text-[#0d1b2f]" />
                  </div>
                  <span className="display text-xl font-bold text-[var(--ink)]">ATAPay</span>
                </div>
                <button onClick={() => setSidebarOpen(false)} className="text-[var(--subtle)] hover:text-[var(--ink)]">
                  <X size={20} />
                </button>
              </div>
              <nav className="flex-1 p-3 space-y-0.5">
                {NAV_ITEMS.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => { onNavigate(item.id); setSidebarOpen(false) }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                      currentPage === item.id
                        ? 'bg-[rgba(172,198,233,0.15)] text-[var(--accent)] border border-[rgba(172,198,233,0.2)]'
                        : 'text-[var(--muted)] hover:bg-[rgba(255,255,255,0.05)] hover:text-[var(--ink)]'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </button>
                ))}
              </nav>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top nav */}
        <header className="sticky top-0 z-30 flex items-center justify-between px-4 lg:px-6 py-3 border-b border-[rgba(255,255,255,0.08)] bg-[rgba(13,27,47,0.85)] backdrop-blur-md">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden text-[var(--subtle)] hover:text-[var(--ink)] p-1"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={22} />
            </button>
            <h1 className="display text-base font-semibold text-[var(--ink)] capitalize">
              {NAV_ITEMS.find((n) => n.id === currentPage)?.label ?? currentPage}
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <NetworkBadge />
            <ConnectKitButton
              customTheme={{
                '--ck-font-family': "'DM Sans', sans-serif",
                '--ck-primary-button-background': '#acc6e9',
                '--ck-primary-button-color': '#0d1b2f',
                '--ck-body-background': '#0f1e34',
                '--ck-body-color': '#f9faf3',
                '--ck-border-radius': '10px',
              }}
            />
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18 }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
