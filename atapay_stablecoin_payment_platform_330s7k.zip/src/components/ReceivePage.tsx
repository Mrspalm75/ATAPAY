import { useState, useRef } from 'react'
import { useAccount } from 'wagmi'
import { QRCodeSVG } from 'qrcode.react'
import { motion, AnimatePresence } from 'framer-motion'
import { Copy, Share2, Download, Check, Wallet, AlertCircle } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'
import { toast } from 'sonner'
import { ARC_CHAIN_ID } from '@/config'

function useCopy(text: string) {
  const [copied, setCopied] = useState(false)
  function copy() {
    void navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast.success('Copied to clipboard')
    }).catch(() => {})
  }
  return { copied, copy }
}

export default function ReceivePage() {
  const { address, isConnected } = useAccount()
  const [tab, setTab] = useState<'address' | 'request'>('address')
  const [reqAmount, setReqAmount] = useState('')
  const [reqDescription, setReqDescription] = useState('')
  const qrRef = useRef<HTMLDivElement>(null)

  // Plain address QR
  const plainQRValue = address ?? ''
  // EIP-681 payment request URI: ethereum:<address>@<chainId>/transfer?...
  const hasRequest = !!reqAmount && parseFloat(reqAmount) > 0
  const reqAmountRaw = hasRequest ? Math.round(parseFloat(reqAmount) * 1_000_000) : 0
  const paymentRequestURI = address
    ? `ethereum:${address}@${ARC_CHAIN_ID}/transfer?address=${address}&uint256=${reqAmountRaw}${reqDescription ? `&label=${encodeURIComponent(reqDescription)}` : ''}`
    : ''
  const qrValue = tab === 'address' ? plainQRValue : (hasRequest ? paymentRequestURI : plainQRValue)

  const { copied: copiedAddr, copy: copyAddr } = useCopy(address ?? '')
  const { copy: copyReq } = useCopy(qrValue)

  function handleDownloadQR() {
    const svg = qrRef.current?.querySelector('svg')
    if (!svg) return
    const svgData = new XMLSerializer().serializeToString(svg)
    const blob = new Blob([svgData], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `atapay-${tab === 'address' ? 'address' : 'payment-request'}.svg`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('QR code downloaded')
  }

  async function handleShare() {
    if (navigator.share) {
      await navigator.share({
        title: 'Pay me USDC on Arc',
        text: tab === 'address'
          ? `Send USDC to my address on Arc Mainnet: ${address}`
          : `Pay me ${reqAmount} USDC on Arc Mainnet: ${paymentRequestURI}`,
        url: tab === 'request' && hasRequest ? paymentRequestURI : undefined,
      }).catch(() => {})
    } else {
      copyReq()
    }
  }

  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] gap-4 px-4">
        <Wallet size={40} className="text-[var(--accent)]" />
        <p className="text-[var(--muted)] text-center">Connect your wallet to receive USDC</p>
      </div>
    )
  }

  return (
    <div className="p-4 lg:p-6 max-w-md mx-auto space-y-4">
      {/* Tabs */}
      <div className="flex rounded-xl border border-[var(--border)] bg-[var(--surface)] p-1 gap-1">
        {(['address', 'request'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${
              tab === t
                ? 'bg-[var(--accent)] text-[#0d1b2f]'
                : 'text-[var(--muted)] hover:text-[var(--ink)]'
            }`}
          >
            {t === 'address' ? 'Wallet Address' : 'Payment Request'}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 space-y-5">
            {/* QR Code */}
            <div className="flex justify-center">
              <div ref={qrRef} className="p-4 bg-white rounded-2xl shadow-lg">
                {qrValue ? (
                  <QRCodeSVG
                    value={qrValue}
                    size={200}
                    level="H"
                    includeMargin={false}
                    imageSettings={{
                      src: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxNiIgY3k9IjE2IiByPSIxNiIgZmlsbD0iIzI3NzVDQSIvPjx0ZXh0IHg9IjE2IiB5PSIyMiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE4IiBmaWxsPSJ3aGl0ZSIgZm9udC13ZWlnaHQ9ImJvbGQiPiQ8L3RleHQ+PC9zdmc+',
                      height: 28,
                      width: 28,
                      excavate: true,
                    }}
                  />
                ) : (
                  <div className="w-[200px] h-[200px] flex items-center justify-center bg-gray-100 rounded-xl">
                    <span className="text-gray-400 text-sm">No address</span>
                  </div>
                )}
              </div>
            </div>

            {/* Type badge */}
            <div className="flex justify-center">
              <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${
                tab === 'address'
                  ? 'border-[rgba(172,198,233,0.3)] bg-[rgba(172,198,233,0.1)] text-[var(--accent)]'
                  : 'border-[rgba(141,216,159,0.3)] bg-[rgba(141,216,159,0.1)] text-[#8dd89f]'
              }`}>
                <TokenUSDC variant="branded" size={14} />
                {tab === 'address' ? 'Plain wallet address' : hasRequest ? `Request ${reqAmount} USDC` : 'Payment request (enter amount)'}
              </span>
            </div>

            {/* Address display */}
            <div className="rounded-xl bg-[var(--surface-muted)] border border-[var(--border)] p-3">
              <p className="text-xs text-[var(--subtle)] mb-1">Your Arc Mainnet Address</p>
              <p className="mono text-sm text-[var(--ink)] break-all select-all">{address}</p>
            </div>

            {/* Request fields (only on request tab) */}
            {tab === 'request' && (
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Requested Amount</label>
                  <div className="relative">
                    <input
                      type="number"
                      value={reqAmount}
                      onChange={(e) => setReqAmount(e.target.value)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                      className="w-full display text-xl bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 pr-20 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)] tabular-nums"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-semibold text-[var(--muted)]">USDC</span>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold uppercase tracking-wider text-[var(--subtle)]">Description (optional)</label>
                  <input
                    type="text"
                    value={reqDescription}
                    onChange={(e) => setReqDescription(e.target.value)}
                    placeholder="e.g. For invoice #123"
                    className="w-full text-sm bg-[var(--surface-muted)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--ink)] placeholder-[var(--subtle)] focus:outline-none focus:border-[var(--border-strong)]"
                  />
                </div>
              </div>
            )}

            {tab === 'request' && (
              <div className="flex items-start gap-2 text-xs text-[var(--subtle)] bg-[var(--surface-muted)] rounded-lg p-3 border border-[var(--border)]">
                <AlertCircle size={13} className="shrink-0 mt-0.5" />
                Scanning this QR code does not create or guarantee a payment. Always verify settlement on-chain.
              </div>
            )}

            {/* Actions */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={copyAddr}
                className="flex flex-col items-center gap-1.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--surface-muted)] text-[var(--muted)] hover:text-[var(--ink)] hover:bg-[var(--surface-strong)] transition-colors text-xs font-medium"
              >
                {copiedAddr ? <Check size={16} className="text-[#8dd89f]" /> : <Copy size={16} />}
                Copy Address
              </button>
              <button
                onClick={handleDownloadQR}
                className="flex flex-col items-center gap-1.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--surface-muted)] text-[var(--muted)] hover:text-[var(--ink)] hover:bg-[var(--surface-strong)] transition-colors text-xs font-medium"
              >
                <Download size={16} />
                Download QR
              </button>
              <button
                onClick={() => { void handleShare() }}
                className="flex flex-col items-center gap-1.5 py-3 rounded-xl border border-[var(--border)] bg-[var(--surface-muted)] text-[var(--muted)] hover:text-[var(--ink)] hover:bg-[var(--surface-strong)] transition-colors text-xs font-medium"
              >
                <Share2 size={16} />
                Share
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
