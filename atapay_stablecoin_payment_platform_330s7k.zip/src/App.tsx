import { useState } from 'react'
import Layout, { type Page } from './components/Layout'
import Dashboard from './components/Dashboard'
import SendPage from './components/SendPage'
import ReceivePage from './components/ReceivePage'
import PaymentLinksPage from './components/PaymentLinksPage'
import InvoicesPage from './components/InvoicesPage'
import TransactionsPage from './components/TransactionsPage'
import MerchantPage from './components/MerchantPage'
import SettingsPage from './components/SettingsPage'

export default function App() {
  const [page, setPage] = useState<Page>('dashboard')

  function renderPage() {
    switch (page) {
      case 'dashboard': return <Dashboard onNavigate={setPage} />
      case 'send': return <SendPage />
      case 'receive': return <ReceivePage />
      case 'payments': return <PaymentLinksPage />
      case 'invoices': return <InvoicesPage />
      case 'transactions': return <TransactionsPage />
      case 'merchant': return <MerchantPage onNavigate={setPage} />
      case 'settings': return <SettingsPage />
      default: return <Dashboard onNavigate={setPage} />
    }
  }

  return (
    <Layout currentPage={page} onNavigate={setPage}>
      {renderPage()}
    </Layout>
  )
}
